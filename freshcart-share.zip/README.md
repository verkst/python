# FreshCart — Beginner E-commerce Project

A small full-stack e-commerce example built with Flask, React, and a JSON file. It includes product listing/details, a browser-side cart, cart totals, and checkout that saves orders in `backend/data.json`.

## Project structure

```
ecommerce-fresher-project/
├── backend/    # Flask API and JSON data
├── frontend/   # React application
├── requirements.txt
└── README.md
```

## Run the backend

In the project folder:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
python backend/app.py
```

The API runs at `http://127.0.0.1:5000`.

For a beginner-friendly explanation of the Flask API, data file, validation, and endpoints, see [the backend guide](backend/README.md).

## Run the frontend

In a second terminal:

```powershell
cd frontend
npm install
npm run dev
```

Open the local URL Vite prints (normally `http://localhost:5173`). Keep the Flask server running while you use the frontend.

## API endpoints

- `GET /api/products` — list products
- `GET /api/products/<id>` — product details
- `POST /api/orders` — save a checkout order

Example request body:

```json
{
  "customer": { "name": "Sam", "email": "sam@example.com", "address": "123 Main Street" },
  "items": [{ "productId": 1, "quantity": 2 }]
}
```
