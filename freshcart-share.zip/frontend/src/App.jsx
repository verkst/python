import { useEffect, useMemo, useState } from "react";

const API_URL = "http://127.0.0.1:5000/api";

function formatPrice(price) {
  return new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    minimumFractionDigits: 2,
  }).format(price);
}

function ProductCard({ product, onView, onAdd }) {
  return <article className="product-card">
    <img src={product.image} alt={product.name} />
    <div className="product-content">
      <h3>{product.name}</h3>
      <p>{product.description}</p>
      <strong>{formatPrice(product.price)}</strong>
      <div className="button-row">
        <button className="secondary" onClick={() => onView(product)}>Details</button>
        <button onClick={() => onAdd(product)}>Add to cart</button>
      </div>
    </div>
  </article>;
}

function Cart({ cart, onRemove, total, onCheckout }) {
  return <aside className="cart">
    <h2>Your cart</h2>
    {cart.length === 0 ? <p className="muted">Your cart is empty.</p> : <>
      {cart.map((item) => <div className="cart-item" key={item.id}>
        <div><strong>{item.name}</strong><small>{item.quantity} × {formatPrice(item.price)}</small></div>
        <button className="remove" onClick={() => onRemove(item.id)}>Remove</button>
      </div>)}
      <div className="total"><span>Total</span><strong>{formatPrice(total)}</strong></div>
      <button className="checkout-button" onClick={onCheckout}>Checkout</button>
    </>}
  </aside>;
}

function CheckoutForm({ cart, onClose, onOrderPlaced }) {
  const [form, setForm] = useState({ name: "", email: "", address: "" });
  const [error, setError] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  async function submitOrder(event) {
    event.preventDefault();
    setError("");
    if (!form.name.trim() || !form.email.trim() || !form.address.trim()) {
      setError("Please complete all fields."); return;
    }
    setIsSubmitting(true);
    try {
      const response = await fetch(`${API_URL}/orders`, {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ customer: form, items: cart.map(({ id, quantity }) => ({ productId: id, quantity })) })
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || "Could not place your order.");
      onOrderPlaced(result.message);
    } catch (requestError) { setError(requestError.message); }
    finally { setIsSubmitting(false); }
  }

  return <div className="modal-backdrop"><form className="modal" onSubmit={submitOrder}>
    <button type="button" className="close" onClick={onClose} aria-label="Close">×</button>
    <h2>Checkout</h2><p>Enter your details to save your order.</p>
    {error && <p className="error">{error}</p>}
    {Object.keys(form).map((field) => <label key={field}>{field[0].toUpperCase() + field.slice(1)}
      {field === "address" ? <textarea required value={form[field]} onChange={(e) => setForm({ ...form, [field]: e.target.value })} /> :
        <input required type={field === "email" ? "email" : "text"} value={form[field]} onChange={(e) => setForm({ ...form, [field]: e.target.value })} />}
    </label>)}
    <button disabled={isSubmitting}>{isSubmitting ? "Saving order..." : "Place order"}</button>
  </form></div>;
}

export default function App() {
  const [products, setProducts] = useState([]);
  const [cart, setCart] = useState([]);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [showCheckout, setShowCheckout] = useState(false);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  useEffect(() => { fetch(`${API_URL}/products`).then((response) => {
    if (!response.ok) throw new Error("Could not load products. Is the Flask server running?");
    return response.json();
  }).then(setProducts).catch((loadError) => setError(loadError.message)); }, []);

  const total = useMemo(() => cart.reduce((sum, item) => sum + item.price * item.quantity, 0), [cart]);
  function addToCart(product) { setCart((current) => {
    const existing = current.find((item) => item.id === product.id);
    return existing ? current.map((item) => item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item) : [...current, { ...product, quantity: 1 }];
  }); setMessage(`${product.name} added to cart.`); }
  function removeFromCart(id) { setCart((current) => current.filter((item) => item.id !== id)); }
  function orderPlaced(successMessage) { setCart([]); setShowCheckout(false); setMessage(successMessage); }

  return <><header><div><span className="eyebrow">E-Commerce</span><h1>FreshCart</h1></div><span className="cart-count">Cart: {cart.reduce((sum, item) => sum + item.quantity, 0)}</span></header>
    <main>{message && <p className="success">{message}</p>}{error && <p className="error">{error}</p>}
      {selectedProduct && <section className="detail"><img src={selectedProduct.image} alt={selectedProduct.name} /><div><button className="back" onClick={() => setSelectedProduct(null)}>← Back to products</button><h2>{selectedProduct.name}</h2><p>{selectedProduct.description}</p><strong className="detail-price">{formatPrice(selectedProduct.price)}</strong><button onClick={() => addToCart(selectedProduct)}>Add to cart</button></div></section>}
      {!selectedProduct && <section><h2>Products</h2><p className="muted">A small collection of useful everyday items.</p><div className="product-grid">{products.map((product) => <ProductCard key={product.id} product={product} onView={setSelectedProduct} onAdd={addToCart} />)}</div></section>}
      <Cart cart={cart} total={total} onRemove={removeFromCart} onCheckout={() => setShowCheckout(true)} />
    </main>{showCheckout && <CheckoutForm cart={cart} onClose={() => setShowCheckout(false)} onOrderPlaced={orderPlaced} />}</>;
}
