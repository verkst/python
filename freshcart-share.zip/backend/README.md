# FreshCart Backend Guide

This folder contains the backend (server-side) part of FreshCart. It is a small **Flask API** that gives the React frontend product data and saves completed orders.

If you are new to backend development, think of it like this:

```text
Browser (React frontend)  --HTTP request-->  Flask API  --reads/writes-->  data.json
```

The browser never reads `data.json` directly. It asks the API for products or sends the API an order. The API checks the request, performs the calculation, and then saves valid orders.

## Files in this folder

| File | Purpose |
| --- | --- |
| `app.py` | Starts Flask and contains every API route and validation rule. |
| `data.json` | A lightweight local database containing products and orders. |
| `README.md` | This guide. |

## What Flask does

[Flask](https://flask.palletsprojects.com/) is a Python framework for building web servers. In this project, it listens on `http://127.0.0.1:5000` and responds to requests beginning with `/api`.

The important imports in `app.py` are:

```python
from flask import Flask, jsonify, request
from flask_cors import CORS
```

- `Flask` creates the server application.
- `jsonify` converts Python lists and dictionaries into JSON responses.
- `request` reads data sent by the frontend.
- `CORS` lets the frontend on a different local port (usually `5173`) call this API on port `5000` during development.

`DATA_FILE` builds a reliable path to `data.json`, based on the location of `app.py`. This means the server can find the data file even if it is started from a different terminal folder.

## Run the backend

From the project root:

```bash
# Create the virtual environment once
python3 -m venv .venv

# macOS/Linux: activate it in each new terminal
source .venv/bin/activate

# Install packages once (or after requirements.txt changes)
pip install -r requirements.txt

# Start the API
python backend/app.py
```

On Windows PowerShell, activate the environment with:

```powershell
.\.venv\Scripts\Activate.ps1
```

Flask runs in debug mode. It reloads when `app.py` changes and shows useful errors while developing. Do not use debug mode for a production deployment.

## The JSON data file

`data.json` has two top-level lists:

```json
{
  "products": [],
  "orders": []
}
```

### Product shape

Each product needs an `id`, `name`, `price`, `description`, and `image`:

```json
{
  "id": 5,
  "name": "Notebook",
  "price": 149.0,
  "description": "A ruled notebook for everyday notes.",
  "image": "https://example.com/notebook.jpg"
}
```

The frontend displays prices as Indian rupees (`₹`). The backend stores prices as numbers and uses them to calculate order totals. When adding products, enter the numeric rupee amount without a currency sign, for example `149.0`, not `"₹149"`.

### Order shape

When a customer places an order, the backend adds an object similar to this to `orders`:

```json
{
  "id": 2,
  "customer": {
    "name": "Sam",
    "email": "sam@example.com",
    "address": "123 Main Street"
  },
  "items": [
    {
      "productId": 1,
      "name": "Classic White T-Shirt",
      "price": 19.99,
      "quantity": 2,
      "itemTotal": 39.98
    }
  ],
  "total": 39.98,
  "createdAt": "2026-08-13T12:30:00"
}
```

Notice that the backend copies the product name and price into the order. This keeps a record of what the customer bought at that time, even if the product is changed later.

## How `app.py` works

### Reading and saving data

`read_data()` opens `data.json` and turns its JSON into a Python dictionary. `save_data(data)` writes the updated dictionary back with indentation, making the file easy to read.

For this beginner project, JSON is a convenient replacement for a database. It is not suitable for a real shop with many users because simultaneous writes can overwrite each other. A production version should use a database such as PostgreSQL or MySQL.

### API routes

A route connects a URL and HTTP method to a Python function.

| Method and URL | Function | What it does |
| --- | --- | --- |
| `GET /api/products` | `get_products` | Returns the complete product list. |
| `GET /api/products/<product_id>` | `get_product` | Returns one product by numeric ID. |
| `POST /api/orders` | `create_order` | Validates, calculates, saves, and returns a new order. |

#### Get all products

`get_products()` reads the data and returns `data["products"]`. `jsonify()` sends that Python list back to the browser as JSON with a successful `200` response.

Try it in a browser or terminal:

```bash
curl http://127.0.0.1:5000/api/products
```

#### Get one product

`get_product(product_id)` receives the ID from the URL. The `<int:product_id>` part means Flask only accepts an integer there. The function searches the products list using `next(...)`.

- If it finds a match, it returns that product with `200 OK`.
- If no match exists, it returns `{"error": "Product not found."}` with `404 Not Found`.

For example:

```bash
curl http://127.0.0.1:5000/api/products/1
```

#### Create an order

`create_order()` handles checkout requests. The frontend sends a JSON body with `customer` and `items`.

The function follows this order:

1. Reads the JSON body with `request.get_json(silent=True)`.
2. Ensures name, email, address, and at least one cart item are present.
3. Checks that the email contains `@`.
4. Reads the current products from `data.json` and looks each one up by `productId`.
5. Rejects unknown products, non-integer quantities, and quantities below `1`.
6. Calculates each `itemTotal` and the overall `total` on the server. This is important: prices sent by the browser are not trusted.
7. Creates an ID and timestamp, adds the order to `data["orders"]`, and saves the file.
8. Returns the saved order with `201 Created`.

Send a test order:

```bash
curl -X POST http://127.0.0.1:5000/api/orders \
  -H "Content-Type: application/json" \
  -d '{
    "customer": {"name": "Sam", "email": "sam@example.com", "address": "123 Main Street"},
    "items": [{"productId": 1, "quantity": 2}]
  }'
```

### Validation errors

Invalid requests return a JSON error and the HTTP status `400 Bad Request`. Common reasons include:

- Missing order body, customer details, or cart items.
- An email that does not contain `@`.
- A product ID that is not in `data.json`.
- A quantity that is not an integer or is less than `1`.

The validation is intentionally simple for learning. In a production project, use robust email validation, authentication, stock checks, payment processing, and more detailed validation.

## How the frontend uses this API

The frontend sets its base API URL in `frontend/src/App.jsx`:

```js
const API_URL = "http://127.0.0.1:5000/api";
```

When the React app first loads, it requests `GET /products`. During checkout, it sends `POST /orders`. Keep both the Flask backend and Vite frontend running while testing the full app.

## Good next improvements

- Generate order IDs safely instead of using `len(orders) + 1`.
- Store money as integer paise (for example, `1999`) to avoid floating-point rounding issues.
- Replace `data.json` with a real database.
- Add stock quantity and reduce it only after a successful order.
- Add automated tests with Flask's test client.
- Move the API URL and secret configuration into environment variables.
