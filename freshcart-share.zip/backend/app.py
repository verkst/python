from flask import Flask, jsonify, request
from flask_cors import CORS
from pathlib import Path
import json
from datetime import datetime


app = Flask(__name__)
CORS(app)

DATA_FILE = Path(__file__).parent / "data.json"


def read_data():
    """Read products and orders from the local JSON file."""
    with open(DATA_FILE, "r", encoding="utf-8") as file:
        return json.load(file)


def save_data(data):
    """Save updated orders back to the local JSON file."""
    with open(DATA_FILE, "w", encoding="utf-8") as file:
        json.dump(data, file, indent=2)


@app.route("/api/products", methods=["GET"])
def get_products():
    data = read_data()
    return jsonify(data["products"])


@app.route("/api/products/<int:product_id>", methods=["GET"])
def get_product(product_id):
    data = read_data()
    product = next((item for item in data["products"] if item["id"] == product_id), None)

    if product is None:
        return jsonify({"error": "Product not found."}), 404

    return jsonify(product)


@app.route("/api/orders", methods=["POST"])
def create_order():
    order_request = request.get_json(silent=True)

    if not order_request:
        return jsonify({"error": "Please send order details."}), 400

    customer = order_request.get("customer", {})
    items = order_request.get("items", [])
    required_fields = ["name", "email", "address"]

    if not all(customer.get(field, "").strip() for field in required_fields):
        return jsonify({"error": "Name, email, and address are required."}), 400

    if "@" not in customer["email"]:
        return jsonify({"error": "Please enter a valid email address."}), 400

    if not items:
        return jsonify({"error": "Your cart is empty."}), 400

    data = read_data()
    products_by_id = {product["id"]: product for product in data["products"]}
    order_items = []
    total = 0

    for item in items:
        product = products_by_id.get(item.get("productId"))
        quantity = item.get("quantity", 0)
        if product is None or not isinstance(quantity, int) or quantity < 1:
            return jsonify({"error": "One or more cart items are invalid."}), 400

        item_total = product["price"] * quantity
        total += item_total
        order_items.append({
            "productId": product["id"],
            "name": product["name"],
            "price": product["price"],
            "quantity": quantity,
            "itemTotal": item_total,
        })

    new_order = {
        "id": len(data["orders"]) + 1,
        "customer": customer,
        "items": order_items,
        "total": round(total, 2),
        "createdAt": datetime.now().isoformat(timespec="seconds"),
    }
    data["orders"].append(new_order)
    save_data(data)

    return jsonify({"message": "Order placed successfully!", "order": new_order}), 201


if __name__ == "__main__":
    app.run(debug=True)
